package battleshipGame.enums;

public enum Players {
    P1, P2;
}
