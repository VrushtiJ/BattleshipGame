package battleshipGame.enums;

public enum State {
    hit, miss, ship, blank;
}
