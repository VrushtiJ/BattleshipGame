package battleshipGame.services;

import battleshipGame.domain.Request;
import battleshipGame.domain.Response;
import battleshipGame.enums.Players;
import battleshipGame.gameStart.GameBoard;
import battleshipGame.processor.MissilePosition;
import battleshipGame.enums.State;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class GameService {

    @Autowired
    MissilePosition missilePosition;

    public Response fireMissiles(Request request){
        State fireStatus = missilePosition.fireMissile(request.getRowNum(), request.getColNum(), Players.valueOf(request.getPlayer()));
        boolean areAllShipHist = missilePosition.areAllShipsHit(Players.valueOf(request.getPlayer()));
        String message=fireStatus.toString();
        if(areAllShipHist){
            message="All ships are hit!! you've won the game.";
        }
        State[][] updatedBoard = GameBoard.oopGameBoardByPlayer.get(request.getPlayer());
        Response response = new Response(message, updatedBoard);
        return  response;
    }

    public Response showMyOriginalBoard(String player){
        State[][] board = GameBoard.myGameBoardByPlayer.get(Players.valueOf(player));
        return  new Response(null, board);
    }

    public Response showMyGameBoard(String player){
        State[][] board = GameBoard.oopGameBoardByPlayer.get(Players.valueOf(player));
        return new Response(null, board);
    }

}
